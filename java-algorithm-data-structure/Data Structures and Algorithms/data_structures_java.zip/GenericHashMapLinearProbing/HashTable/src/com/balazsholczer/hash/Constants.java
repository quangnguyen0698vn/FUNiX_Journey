package com.balazsholczer.hash;

public class Constants {

	private Constants(){
		
	}
	
	public static final int TABLE_SIZE = 10;

}
