package com.balazsholczer.avl;

public interface Tree {
	public void insert(int data);
	public void traverse();
	public void delete(int data);
}
