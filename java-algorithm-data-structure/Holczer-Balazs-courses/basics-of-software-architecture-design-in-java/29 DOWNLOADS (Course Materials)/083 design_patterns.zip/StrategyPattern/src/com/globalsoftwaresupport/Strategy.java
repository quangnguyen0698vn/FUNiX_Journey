package com.globalsoftwaresupport;

// abstraction 
public interface Strategy {
	public void execute(int num1, int num2);
}
