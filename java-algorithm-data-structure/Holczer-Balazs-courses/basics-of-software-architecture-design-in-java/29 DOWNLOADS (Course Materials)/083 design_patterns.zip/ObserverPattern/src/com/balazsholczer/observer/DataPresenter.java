package com.balazsholczer.observer;

public interface DataPresenter {
	public void showData();
}
