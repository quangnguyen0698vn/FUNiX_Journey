package com.globalsoftwaresupport;

public class StockMarketDataParser {

	public void parseXML() {
		System.out.println("Parsing stock market related XML file...");
	}
}
