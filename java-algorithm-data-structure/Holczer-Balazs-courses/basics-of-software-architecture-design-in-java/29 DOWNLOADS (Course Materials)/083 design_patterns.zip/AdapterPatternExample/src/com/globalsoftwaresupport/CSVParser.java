package com.globalsoftwaresupport;

public interface CSVParser {
	public void parseCSV();
}
