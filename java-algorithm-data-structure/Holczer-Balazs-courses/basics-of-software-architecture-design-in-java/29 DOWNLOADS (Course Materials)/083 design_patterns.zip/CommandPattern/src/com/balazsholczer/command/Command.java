package com.balazsholczer.command;

// command 
public interface Command {
	public void execute();
}
