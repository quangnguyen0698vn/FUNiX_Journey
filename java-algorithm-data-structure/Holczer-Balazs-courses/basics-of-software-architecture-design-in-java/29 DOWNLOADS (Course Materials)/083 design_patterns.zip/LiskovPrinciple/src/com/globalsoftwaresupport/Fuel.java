package com.globalsoftwaresupport;

public interface Fuel {
	public void fuel();
}
