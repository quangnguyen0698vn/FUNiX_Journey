package com.globalsoftwaresupport;

public interface Observer {
	public void update(float price);
}
