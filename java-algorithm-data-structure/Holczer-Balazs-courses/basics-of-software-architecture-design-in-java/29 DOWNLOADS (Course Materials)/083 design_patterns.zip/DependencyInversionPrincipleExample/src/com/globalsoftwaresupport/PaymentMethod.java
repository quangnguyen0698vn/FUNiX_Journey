package com.globalsoftwaresupport;

public interface PaymentMethod {
	public void pay();
}
