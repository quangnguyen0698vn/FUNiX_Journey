package com.globalsoftwaresupport;

public interface ICEO extends IEmployee {
	public void makeDecisions();	
	public void addStocks();
	public void addBonus();
}
