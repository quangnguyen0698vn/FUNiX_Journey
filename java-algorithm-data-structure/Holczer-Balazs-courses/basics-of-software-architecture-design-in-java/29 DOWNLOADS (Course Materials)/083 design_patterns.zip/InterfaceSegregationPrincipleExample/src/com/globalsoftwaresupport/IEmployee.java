package com.globalsoftwaresupport;

public interface IEmployee {
	public void salary();
}
