package com.globalsoftwaresupport;

public interface IManager extends IEmployee {
	public void hire();
	public void train();
	public void addBonus();
}
