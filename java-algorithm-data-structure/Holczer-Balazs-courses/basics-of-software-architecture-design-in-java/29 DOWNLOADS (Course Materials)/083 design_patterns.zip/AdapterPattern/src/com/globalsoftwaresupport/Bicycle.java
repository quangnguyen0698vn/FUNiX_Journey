package com.globalsoftwaresupport;

public class Bicycle {

	public void go() {
		System.out.println("Using bicycle...");
	}
}
