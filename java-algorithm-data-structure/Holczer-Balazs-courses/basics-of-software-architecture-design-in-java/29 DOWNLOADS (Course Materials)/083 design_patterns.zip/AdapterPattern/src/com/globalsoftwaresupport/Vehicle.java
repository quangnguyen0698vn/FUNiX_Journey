package com.globalsoftwaresupport;

public interface Vehicle {
	public void accelerate();
}
