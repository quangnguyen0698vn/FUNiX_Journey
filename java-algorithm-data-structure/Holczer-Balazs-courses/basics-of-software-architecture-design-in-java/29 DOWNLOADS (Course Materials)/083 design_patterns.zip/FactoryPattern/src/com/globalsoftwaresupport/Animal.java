package com.globalsoftwaresupport;

public interface Animal {
	public void eat();
}
