package com.globalsoftwaresupport;

public class Dog implements Animal {

	@Override
	public void eat() {
		System.out.println("Dog is eating...");
	}
}
