package com.globalsoftwaresupport;

public enum AnimalType {
	DOG, CAT, TIGER, LION;
}
