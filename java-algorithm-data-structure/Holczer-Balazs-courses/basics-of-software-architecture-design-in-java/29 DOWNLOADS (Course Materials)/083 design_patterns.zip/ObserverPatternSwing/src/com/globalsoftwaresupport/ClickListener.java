package com.globalsoftwaresupport;

public interface ClickListener {
	public void clicked();
}
