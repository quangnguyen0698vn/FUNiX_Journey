package com.balazsholczer.command;

public interface Command {
	public void execute();
}
