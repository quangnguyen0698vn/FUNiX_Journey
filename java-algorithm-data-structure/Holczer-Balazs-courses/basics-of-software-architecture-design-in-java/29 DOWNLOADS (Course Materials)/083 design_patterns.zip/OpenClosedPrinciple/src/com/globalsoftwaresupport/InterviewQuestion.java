package com.globalsoftwaresupport;

public interface InterviewQuestion {
	public void execute();
}
