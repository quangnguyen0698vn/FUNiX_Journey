package com.globalsoftwaresupport;

public interface Renderer {
	public void showImage();
}
