package com.balazsholczer.facade;

public interface Algorithm {
	public void sort();
}
