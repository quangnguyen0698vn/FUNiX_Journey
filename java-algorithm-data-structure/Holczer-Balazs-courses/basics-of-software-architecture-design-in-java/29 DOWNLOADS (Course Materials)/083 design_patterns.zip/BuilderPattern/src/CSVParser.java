
public interface CSVParser {
	public void parseCSV();
}
