package com.globalsoftwaresupport;

public interface Car {
	public void assemble();
}
