package com.globalsoftwaresupport;

public interface AbstractFactory {
	public Car getCar(String type);
}
