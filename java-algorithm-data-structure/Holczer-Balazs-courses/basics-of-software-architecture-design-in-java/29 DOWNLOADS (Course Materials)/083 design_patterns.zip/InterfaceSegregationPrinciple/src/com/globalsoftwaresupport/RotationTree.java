package com.globalsoftwaresupport;

public interface RotationTree extends Tree{
	public void leftRotation();
	public void rightRotation();
}
