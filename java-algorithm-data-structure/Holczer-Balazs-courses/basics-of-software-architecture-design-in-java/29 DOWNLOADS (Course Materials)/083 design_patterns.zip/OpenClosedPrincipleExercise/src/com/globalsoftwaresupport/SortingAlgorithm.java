package com.globalsoftwaresupport;

public interface SortingAlgorithm {
	public void sort();
}
