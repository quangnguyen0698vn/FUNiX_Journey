package com.globalsoftwaresupport;

public class SortingProcessor {

	public static void execute(SortingAlgorithm algorithm) {
		algorithm.sort();
	}
}
