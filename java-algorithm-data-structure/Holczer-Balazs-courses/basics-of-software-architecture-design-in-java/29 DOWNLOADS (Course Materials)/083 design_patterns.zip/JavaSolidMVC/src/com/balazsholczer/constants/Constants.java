package com.balazsholczer.constants;

public class Constants {

	private Constants(){
		
	}

	public static final String APPLICATION_TITLE = "MVC Pattern";
	
}
