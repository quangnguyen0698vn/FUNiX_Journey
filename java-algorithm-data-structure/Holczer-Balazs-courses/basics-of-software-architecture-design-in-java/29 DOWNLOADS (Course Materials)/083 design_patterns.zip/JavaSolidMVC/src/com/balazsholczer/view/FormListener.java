package com.balazsholczer.view;

public interface FormListener {
	public void okButtonClicked(String personName, String personOccupation);
}
