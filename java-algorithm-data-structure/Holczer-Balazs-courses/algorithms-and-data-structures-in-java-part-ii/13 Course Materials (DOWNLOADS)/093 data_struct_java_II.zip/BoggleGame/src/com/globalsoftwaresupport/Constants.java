package com.globalsoftwaresupport;

public class Constants {

	// we want to prevent this class from being instantiated (new)
	private Constants() {
		
	}
	
	public static final int BOARD_SIZE = 3;
}
