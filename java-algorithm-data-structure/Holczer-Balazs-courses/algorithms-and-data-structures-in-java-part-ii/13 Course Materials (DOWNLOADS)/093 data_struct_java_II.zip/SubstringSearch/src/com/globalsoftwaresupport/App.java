package com.globalsoftwaresupport;

public class App {

	public static void main(String[] args) {
		
		ZAlgorithm algorithm = new ZAlgorithm("aacaaccaaceeeaac!","aac");
		algorithm.search();
	}
}
