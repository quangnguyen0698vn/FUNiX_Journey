Use the enclosed .SQL file in this ZIP folder
to create the sample database described in the book.

You have to use SQL Server Management  or Azure Data Studio
(see the description of these tools in Chapter 3)
to start the SQL script and to create the sample database 
and all four tables that belong to the database.

Each "Chapterxx_Examples" doc file contains examples from the 
corresponding chapter. (For instance, the file Chapter20_Examples.docs contains
all examples from Chapter 20.)
You can use these files to copy and test given examples.
(Some chapters do not have examples, or examples are  not given,
because they are trivial.) 

   
 