SELECT MAX(POPULATION) - MIN(POPULATION) FROM CITY
--https://www.hackerrank.com/challenges/population-density-difference/
