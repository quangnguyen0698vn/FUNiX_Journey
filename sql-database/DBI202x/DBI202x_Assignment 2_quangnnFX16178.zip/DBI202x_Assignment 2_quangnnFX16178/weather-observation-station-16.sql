SELECT CONVERT(DECIMAL(10,4),MIN(LAT_N)) FROM STATION WHERE LAT_N > 38.7780
--https://www.hackerrank.com/challenges/weather-observation-station-16
