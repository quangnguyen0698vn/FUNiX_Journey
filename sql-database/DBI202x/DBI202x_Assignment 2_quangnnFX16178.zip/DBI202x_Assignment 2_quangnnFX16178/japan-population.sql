SELECT SUM(POPULATION) FROM CITY WHERE COUNTRYCODE = 'JPN'
--https://www.hackerrank.com/challenges/japan-population/
