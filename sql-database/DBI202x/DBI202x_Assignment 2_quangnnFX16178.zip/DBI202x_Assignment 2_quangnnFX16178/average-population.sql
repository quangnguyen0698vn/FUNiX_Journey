SELECT ROUND(AVG(POPULATION),0) FROM CITY
--https://www.hackerrank.com/challenges/average-population
