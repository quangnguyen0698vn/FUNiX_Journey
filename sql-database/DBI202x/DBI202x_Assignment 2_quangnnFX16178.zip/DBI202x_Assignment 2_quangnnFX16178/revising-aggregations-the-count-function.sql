SELECT COUNT(*) FROM CITY WHERE POPULATION > 100000
--https://www.hackerrank.com/challenges/revising-aggregations-the-count-function
