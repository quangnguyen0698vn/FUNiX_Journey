SELECT CONVERT(DECIMAL(10,4), MAX(LAT_N)) FROM STATION WHERE LAT_N < 137.2345
--https://www.hackerrank.com/challenges/weather-observation-station-14
