SELECT * FROM CITY WHERE COUNTRYCODE = "JPN";
--https://www.hackerrank.com/challenges/japanese-cities-attributes/problem
