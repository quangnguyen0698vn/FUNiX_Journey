SELECT * FROM CITY;
--https://www.hackerrank.com/challenges/select-all-sql/problem
