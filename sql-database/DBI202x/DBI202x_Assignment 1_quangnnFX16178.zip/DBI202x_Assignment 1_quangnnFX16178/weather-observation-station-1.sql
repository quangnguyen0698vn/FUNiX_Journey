SELECT CITY, STATE FROM STATION;
--https://www.hackerrank.com/challenges/weather-observation-station-1/problem
