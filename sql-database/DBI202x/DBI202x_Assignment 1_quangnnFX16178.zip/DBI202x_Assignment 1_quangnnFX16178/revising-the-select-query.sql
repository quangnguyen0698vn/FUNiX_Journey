SELECT * FROM CITY WHERE POPULATION > 100000 AND COUNTRYCODE = "USA";
--https://www.hackerrank.com/challenges/revising-the-select-query/problem
