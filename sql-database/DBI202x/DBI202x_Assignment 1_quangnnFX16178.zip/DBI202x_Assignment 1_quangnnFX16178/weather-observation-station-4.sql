SELECT COUNT(CITY) - COUNT(DISTINCT CITY) FROM STATION;
--https://www.hackerrank.com/challenges/weather-observation-station-4/problem
