SELECT name FROM Employee ORDER BY name;
--https://www.hackerrank.com/challenges/name-of-employees/problem
