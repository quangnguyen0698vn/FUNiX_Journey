SELECT NAME FROM CITY WHERE POPULATION > 120000 AND COUNTRYCODE = "USA";
--https://www.hackerrank.com/challenges/revising-the-select-query-2/problem
