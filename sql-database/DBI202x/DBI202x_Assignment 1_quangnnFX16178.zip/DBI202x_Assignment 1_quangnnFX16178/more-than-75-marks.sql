SELECT NAME FROM STUDENTS WHERE MARKS > 75 ORDER BY substring(NAME, LEN(NAME)-2, 3), ID;
--https://www.hackerrank.com/challenges/more-than-75-marks/problem
